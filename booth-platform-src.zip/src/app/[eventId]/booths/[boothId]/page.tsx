import ProductExplorer from "@/src/component/product/ProductExplorer";
import FollowButton from "@/src/component/booth/FollowButton";

import { createClient } from "@/src/lib/supabase/server";
import { getBooth, isFollowingBooth } from "@/src/lib/data/booth";
import { getProductSummaries } from "@/src/lib/data/product";

export default async function Page({
  params,
}: {
  params: Promise<{ boothId: string }>;
}) {
  const { boothId } = await params;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const booth = await getBooth(boothId);

  if (!booth) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-16">
        <p className="text-center text-zinc-500">
          부스를 찾을 수 없습니다.
        </p>
      </main>
    );
  }

  const [products, initialFollowed] = await Promise.all([
    getProductSummaries(boothId),
    user
      ? isFollowingBooth(user.id, boothId)
      : Promise.resolve(false),
  ]);

  const isAdult = booth.category === "ADULT";

  return (
    <main className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
      {/* Booth */}
      <header className="border-b border-zinc-800 pb-10">
        <div className="flex items-start justify-between gap-8">
          {/* Info */}
          <div className="min-w-0 flex-1">
            {/* Meta */}
            <div className="min-w-0 flex-1">
              {/* Meta */}
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-md font-medium text-zinc-400">
                    <span>[{booth.boothNumber}]</span>
                    <span>
                      {booth.category === "ADULT" ? "성인 부스" : "일반 부스"}
                    </span>
                  </div>

                  {/* Name */}
                  <h1 className="pt-1 text-2xl font-bold tracking-tight text-white sm:text-4xl">
                    {booth.boothName}
                  </h1>
                </div>

                {/* Follow */}
                <div className="ml-auto shrink-0">
                  <FollowButton
                    boothId={booth.id}
                    currentUserId={user?.id}
                    initialFollowed={initialFollowed}
                  />
                </div>
              </div>
            </div>


            {/* Description */}
            {booth.description && (
              <p className="mt-5 max-w-2xl whitespace-pre-wrap text-base leading-7 text-zinc-300">
                {booth.description}
              </p>
            )}

            {/* Artists */}
            {booth.artistNames.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2">
                {booth.artistNames.map((artistName) => (
                  <span
                    key={artistName}
                    className="rounded-full border border-primary px-3 py-1 text-sm font-medium text-zinc-300"
                  >
                    {artistName}
                  </span>
                ))}
              </div>
            )}
          </div>


        </div>
      </header>

      {/* Products */}
      <section className="pt-10">
        <div className="mb-6 flex items-baseline ">
          <h2 className="text-xl sm:text-2xl font-semibold text-white">
            판매 제품 {products.length}개
          </h2>
        </div>

        <ProductExplorer
          products={products}
          currentUserId={user?.id}
        />
      </section>

    </main>
  );
}
