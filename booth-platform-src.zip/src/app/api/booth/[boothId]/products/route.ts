// src/app/api/booth/[boothId]/products/route.ts
import { NextResponse } from "next/server";
import { requireBoothArtist } from "@/src/lib/auth/requireBoothArtist";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ boothId: string }> }
) {
  const { boothId } = await params;
  const body = await request.json();

  const {
    name,
    mainImageUrl,
    price,
    category,
    subCategory,
    initialQuantity,
    purchaseLimit,
    description,
    artistIds,
    options,
  } = body;

  if (!name?.trim()) {
    return NextResponse.json(
      { error: "상품명을 입력해주세요." },
      { status: 400 }
    );
  }

  if (!category || !subCategory) {
    return NextResponse.json(
      { error: "상품 카테고리를 선택해주세요." },
      { status: 400 }
    );
  }

  if (price === undefined || price === null || Number(price) < 0) {
    return NextResponse.json(
      { error: "가격을 올바르게 입력해주세요." },
      { status: 400 }
    );
  }

  if (!mainImageUrl?.trim()) {
    return NextResponse.json(
      { error: "대표 이미지를 업로드해주세요." },
      { status: 400 }
    );
  }

  if (!Array.isArray(artistIds) || artistIds.length === 0) {
    return NextResponse.json(
      { error: "상품 작가를 선택해주세요." },
      { status: 400 }
    );
  }

  if (!Array.isArray(options)) {
    return NextResponse.json(
      { error: "상품 옵션이 올바르지 않습니다." },
      { status: 400 }
    );
  }

  const authResult = await requireBoothArtist(boothId);

  if (authResult instanceof NextResponse) return authResult;

  const { supabase } = authResult;

  // 작가 이름 스냅샷 생성 — 클라이언트가 보낸 이름을 믿지 않고 서버에서 직접 조회
  const { data: artistData, error: artistError } = await supabase
    .from("users")
    .select("id, name")
    .in("id", artistIds);

  if (artistError || !artistData || artistData.length !== artistIds.length) {
    return NextResponse.json(
      { error: "유효하지 않은 작가가 포함되어 있습니다." },
      { status: 400 }
    );
  }

  const nameMap = new Map(artistData.map((a) => [a.id, a.name]));
  const artistNames = artistIds.map((id: string) => nameMap.get(id)!);

  const hasOptions = options.length > 0;

  const productInitialQuantity = hasOptions
    ? null
    : initialQuantity === null || initialQuantity === ""
      ? null
      : Number(initialQuantity);

  const { data: product, error } = await supabase
    .from("products")
    .insert({
      booth_id: boothId,
      main_image_url: mainImageUrl.trim(),
      name: name.trim(),
      price: Number(price),
      category,
      sub_category: subCategory,

      initial_quantity: productInitialQuantity,
      remaining_quantity: productInitialQuantity,

      purchase_limit:
        purchaseLimit === null || purchaseLimit === ""
          ? null
          : Number(purchaseLimit),

      description: description?.trim() ?? "",
      artist_ids: artistIds,
      artist_names: artistNames,
    })
    .select(
      "id, booth_id, main_image_url, sample_images, name, price, category, sub_category, initial_quantity, purchase_limit, description, remaining_quantity, artist_ids, artist_names"
    )
    .single();

  if (error) {
    console.error(error);

    return NextResponse.json(
      { error: "상품 추가에 실패했습니다." },
      { status: 500 }
    );
  }

  // 옵션이 있는 경우 상품 수량은 null이고 옵션별 수량을 저장
  if (hasOptions) {
    const optionRows = options.map(
      (option: {
        name: string;
        initialQuantity: number;
      }) => ({
        product_id: product.id,
        name: option.name.trim(),
        initial_quantity: Number(option.initialQuantity),
        remaining_quantity: Number(option.initialQuantity),
      })
    );

    const { error: optionError } = await supabase
      .from("product_options")
      .insert(optionRows);

    if (optionError) {
      console.error(optionError);

      await supabase
        .from("products")
        .delete()
        .eq("id", product.id);

      return NextResponse.json(
        { error: "상품 옵션 추가에 실패했습니다." },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ product }, { status: 201 });
}