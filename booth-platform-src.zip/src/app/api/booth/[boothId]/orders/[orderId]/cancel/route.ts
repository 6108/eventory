import { NextResponse } from "next/server";
import { createClient } from "@/src/lib/supabase/server";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ boothId: string; orderId: string }> }
) {
  const { boothId } = await params;
  const { orderItemId, quantity } = await request.json();

  if (!orderItemId || !quantity || quantity <= 0) {
    return NextResponse.json(
      { error: "취소 항목과 수량을 확인해주세요." },
      { status: 400 }
    );
  }

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "로그인이 필요합니다." }, { status: 401 });
  }

  const { data: artist } = await supabase
    .from("booth_artists")
    .select("booth_id")
    .eq("booth_id", boothId)
    .eq("artist_id", user.id)
    .maybeSingle();

  if (!artist) {
    return NextResponse.json({ error: "취소 권한이 없습니다." }, { status: 403 });
  }

  const { data, error } = await supabase.rpc("cancel_order_item", {
    p_order_item_id: orderItemId,
    p_cancel_quantity: quantity,
  });

  if (error) {
    console.error(error);

    const message =
      error.message === "invalid cancel quantity"
        ? "취소 가능한 수량을 초과했습니다."
        : error.message === "order already cancelled"
          ? "이미 취소된 주문입니다."
          : "취소 처리에 실패했습니다.";

    return NextResponse.json({ error: message }, { status: 400 });
  }

  return NextResponse.json(data);
}