export type OrderRequestItem = {
  id: string;
  orderRequestId: string;
  productId: string;
  optionId: string | null;
  productName: string;
  optionName: string | null;
  quantity: number;
};

export type OrderRequestStatus =
  | "requested"
  | "checked"
  | "cancelled";

export type OrderRequest = {
  id: string;
  boothId: string;
  customerId: string;
  customerNickname: string;
  items: OrderRequestItem[];
  status: OrderRequestStatus;
  orderId: string | null;
  createdAt: string;
  updatedAt: string;
};